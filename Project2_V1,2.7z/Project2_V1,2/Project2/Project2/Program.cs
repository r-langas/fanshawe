﻿/*
 * Program:         Project2
 * File:            Program.cs
 * Date:            July 30, 2021
 * Course:          INFO-3138
 * Description:     This program will display the emission data of a region or source in years based upon user selection
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Runtime.CompilerServices;
using System.Xml;
using System.Xml.XPath;

namespace Project2
{
    class Program
    {
        // Create variables XML document
        private static string _XML_FILE = "ghg-canada.xml";
        private static XmlDocument _doc = null;

        static void Main(string[] args)
        {
            // Load XML doc
            try
            {
                _doc = new XmlDocument();
                _doc.Load(_XML_FILE);
            }
            catch(FileNotFoundException ex) // file not found
            {
                Console.WriteLine("ERROR: File not found!");
                Console.WriteLine(ex.ToString());
                return;
            }
            catch(XmlException ex)  // XML file errors
            {
                Console.WriteLine("ERROR: XML error! Something is wrong in the file!");
                Console.WriteLine(ex.ToString());
                return;
            }

            // Use XPath to get years, get the lowest and highest values
            int earliestYear = int.MaxValue, latestYear = 0;
            {
                List<string> nodeIt = toListDistinct(getNodes("//emissions/@year"));

                foreach (string val in nodeIt)
                {
                    int num = Int32.Parse(val);

                    if (num < earliestYear)
                    {
                        earliestYear = num;
                        continue;
                    }

                    if (num > latestYear)
                    {
                        latestYear = num;
                    }
                }
            }
            int startRange = -1, endRange = -1;

            // get all regions
            List<string> allRegions = toListDistinct(getNodes("//region/@name"));
            int selectedRegionInd = -1;

            // get all sources
            List<string> allSources = toListDistinct(getNodes("//source/@description"));
            int selectedSourceInd = -1;

            bool notExit = true;

            // Loop main menu
            while (notExit)
            {
                Console.WriteLine("Greenhouse Gas Emissions in Canada");
                Console.WriteLine("===================================\n");

                Console.WriteLine("'Y' to adjust the range of years");
                Console.WriteLine("'R' to select a region");
                Console.WriteLine("'S' to select a specific GHG source");
                Console.WriteLine("'X' to exit the program");

                Console.Write("Your selection: ");
                string response = Console.ReadLine();

                // if and invalid character is inputted
                if(response != "Y" && response != "R" && response != "S" && response != "X")
                {
                    continue;
                }

                switch(response)
                {
                    case "Y":
                        {
                            int startYear, endYear;

                            bool isValid = false;

                            // Get valid start range
                            do
                            {
                                Console.Write($"\nStarting year ({earliestYear} to {latestYear}): ");
                                string responseYear = Console.ReadLine();

                                isValid = Int32.TryParse(responseYear, out startYear);

                                if(isValid)
                                    isValid = earliestYear <= startYear && startYear <= latestYear;

                                if(!isValid)
                                {
                                    Console.WriteLine($"ERROR: Starting year must be an integer between {earliestYear} and {latestYear}.");
                                }
                            } while (!isValid);

                            isValid = false;

                            // Get valid end range
                            do
                            {
                                // start of range to either last year in data set or 5 years away
                                Console.Write($"\nEnding year ({startYear} to {(((startYear + 4) < latestYear) ? startYear + 4 : latestYear)}): ");
                                string responseYear = Console.ReadLine();

                                isValid = Int32.TryParse(responseYear, out endYear);

                                // test if is is greater than the start year, within a 5 year range, and no greater than the last year
                                if(isValid)
                                    isValid = startYear <= endYear && endYear <= startYear + 4 && endYear <= latestYear;

                                if (!isValid)
                                {
                                    Console.WriteLine($"ERROR: Starting year must be an integer between {startYear} and {(((startYear + 4) < latestYear) ? startYear + 4 : latestYear)}.");
                                }
                            } while (!isValid);

                            startRange = startYear;
                            endRange = endYear;

                            Console.WriteLine("\nPress any key to continue");
                            Console.ReadKey();
                            Console.WriteLine();
                        }
                        break;
                    case "R":
                        {
                            // make sure there are at most 5 years otherwise prompt user to input years
                            if(startRange == -1 || endRange == -1)
                            {
                                Console.WriteLine("\nERROR: Please select a range of years that is at most 5 years\n");
                                break;
                            }

                            // Region selection header
                            Console.WriteLine("\nSelect a region by number as shown below...");
                            for(int i = 1; i <= allRegions.Count; i++)
                            {
                                Console.WriteLine((i < 10) ? $" {i}. {allRegions[i - 1]}" : $"{i}. {allRegions[i - 1]}");
                            }

                            // Get selected region and validate
                            bool isValid = false;
                            while (!isValid)
                            {
                                Console.Write("\nEnter a region #: ");
                                string regionString = Console.ReadLine();

                                isValid = Int32.TryParse(regionString, out selectedRegionInd);
                                if (isValid)
                                    // validate if it is within the array (1 - 15)
                                    isValid = 1 <= selectedRegionInd && selectedRegionInd <= allRegions.Count;

                                if (!isValid)
                                    Console.WriteLine($"\n\tERROR: Input must be an integer between 1 and {allRegions.Count}.\n");
                            }
                            // decrement as the array is zero based
                            selectedRegionInd--;

                            // Table header stuff
                            Console.WriteLine($"\nEmmissions in {allRegions[selectedRegionInd]} (Megatonnes)");
                            Console.WriteLine($"{"".PadLeft(allRegions[selectedRegionInd].Length + 27, '-')}\n");
                            Console.Write( "Source".PadLeft(55, ' ') );
                            for(int year = startRange; year <= endRange; year++)
                            {
                                Console.Write( year.ToString().PadLeft(8,' ') );
                            }
                            Console.WriteLine("\n");

                            //  //region[@name='Alberta']/source/emissions[@year>=2005 and @year<=2009]
                            XPathNodeIterator regionData = getNodes($"//region[@name='{allRegions[selectedRegionInd]}']/source/emissions[@year>={startRange} and @year<={endRange}]");
                            regionData.MoveNext();

                            foreach(string src in allSources)
                            {
                                Console.Write(src.PadLeft(55, ' '));

                                for(int i = startRange; i <= endRange; i++)
                                {
                                    decimal tempDec;

                                    if (decimal.TryParse(regionData.Current.Value, out tempDec))
                                        Console.Write(tempDec.ToString("0.000").PadLeft(8, ' '));
                                    else
                                        Console.Write("       -");

                                    regionData.MoveNext();
                                }

                                Console.WriteLine();
                            }

                            Console.WriteLine("\nPress any key to continue.");
                            Console.ReadKey();
                            Console.WriteLine();
                        }
                        break;
                    case "S":
                        {
                            // make sure there are at most 5 years otherwise prompt user to input years
                            if (startRange == -1 || endRange == -1)
                            {
                                Console.WriteLine("\nERROR: Please select a range of years that is at most 5 years\n");
                                break;
                            }

                            // Source selection header
                            Console.WriteLine("\nSelect a region by number as shown below...");
                            for (int i = 1; i <= allSources.Count; i++)
                            {
                                Console.WriteLine((i < 10) ? $" {i}. {allSources[i - 1]}" : $"{i}. {allSources[i - 1]}");
                            }

                            // Get selected source and validate
                            bool isValid = false;
                            while (!isValid)
                            {
                                Console.Write("\nEnter a Source #: ");
                                string sourceString = Console.ReadLine();

                                isValid = Int32.TryParse(sourceString, out selectedSourceInd);

                                if (isValid)
                                    // validate if it is within the array (1 - 8)
                                    isValid = 1 <= selectedSourceInd && selectedSourceInd <= allSources.Count;

                                if (!isValid)
                                    Console.WriteLine($"\n\tERROR: Input must be an integer between 1 and {allSources.Count}.\n");
                            }
                            // decrement as the array is zero based
                            selectedSourceInd--;

                            // Table header stuff
                            Console.WriteLine($"\nEmmissions from {allSources[selectedSourceInd]} (Megatonnes)");
                            Console.WriteLine($"{"".PadLeft(allSources[selectedSourceInd].Length + 29, '-')}\n");
                            Console.Write("Region".PadLeft(55, ' '));
                            for (int year = startRange; year <= endRange; year++)
                            {
                                Console.Write(year.ToString().PadLeft(8, ' '));
                            }
                            Console.WriteLine("\n");

                            foreach (string reg in allRegions)
                            {
                                Console.Write(reg.PadLeft(55, ' '));

                                XPathNodeIterator regionData = getNodes($"//region[@name='{reg}']/source[@description='{allSources[selectedSourceInd]}']/emissions[@year>={startRange} and @year<={endRange}]");
                                regionData.MoveNext();

                                for (int i = startRange; i <= endRange; i++)
                                {
                                    decimal tempDec;

                                    if (decimal.TryParse(regionData.Current.Value, out tempDec))
                                        Console.Write(tempDec.ToString("0.000").PadLeft(8, ' '));
                                    else
                                        Console.Write("       -");

                                    regionData.MoveNext();
                                }

                                Console.WriteLine();
                            }

                            Console.WriteLine("\nPress any key to continue.");
                            Console.ReadKey();
                            Console.WriteLine();
                        }
                        break;
                    case "X":
                        {
                            notExit = false;

                            Console.WriteLine("\nPress any key to continue.");
                            Console.ReadKey();
                            Console.WriteLine();
                        }
                        break;
                }
            }

            Console.WriteLine("All done!");
        }

        //
        //// Return nodes of a XPath
        //
        private static XPathNodeIterator getNodes(string xPath)
        {
            XPathNavigator nav = _doc.CreateNavigator();

            try
            {
                XPathNodeIterator nodeIt = nav.Select(xPath);
                return nodeIt;
            }
            catch(XPathException ex)
            {
                Console.WriteLine($"ERROR: {ex.ToString()}");
                return null;
            }
        }

        //
        //// XPathNodeIterator to list
        //
        private static List<string> toList(XPathNodeIterator nodeIt)
        {
            List<string> li = new List<string>();

            while (nodeIt.MoveNext())
                li.Add(nodeIt.Current.Value);

            return li;
        }

        //
        //// XPathNodeIterator to a distinct list
        //
        private static List<string> toListDistinct(XPathNodeIterator nodeIt)
        {
            List<string> li = new List<string>();

            while (nodeIt.MoveNext())
                li.Add(nodeIt.Current.Value);

            li = new HashSet<String>(li).ToList<string>();

            return li;
        }
    }
}
